/* Unregistered byte shift [0c20426c,0c2042b4). */
int func_0c20426c(char *bytes,int count){int offset=count-1;char *cursor=bytes+offset;char *output=cursor;int carry=0;register int mask=128;for(;cursor>=bytes;cursor--){register int previous=carry;carry=*(unsigned char *)cursor & mask;*cursor=*(signed char *)cursor<<1;if(previous)*output|=1;output--;}if(carry)return 1;return 0;}
