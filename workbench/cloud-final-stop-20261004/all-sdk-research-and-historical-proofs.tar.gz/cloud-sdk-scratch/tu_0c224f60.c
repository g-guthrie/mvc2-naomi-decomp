/* SDK packed-command wrapper, complete extent [0c224f60,0c224f84). */
extern void func_0c213200(int, unsigned int);
int func_0c224f60(volatile int selector, volatile unsigned int value)
{
    func_0c213200(0x74, (selector << 8) | (value & 255));
    return 0;
}
