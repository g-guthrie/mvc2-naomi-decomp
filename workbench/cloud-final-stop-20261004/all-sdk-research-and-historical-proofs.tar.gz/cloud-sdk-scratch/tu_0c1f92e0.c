/* UNREGISTERED SDK input-service group [0c1f92e0,0c1f953c). */
extern int dat_0c345420;
extern int dat_0c345424[4];
extern int dat_0c345434;
extern int dat_0c345438;
extern int dat_0c345440;
extern int dat_0c345444;
extern int dat_0c343d48;
extern int dat_0c353f3c;
extern unsigned int dat_0c34543c;
extern unsigned char dat_0c343d60;
extern int *func_0c1f9190(void);
extern int func_0c1f9290(void);
extern int func_0c1f7570(void);
extern void func_0c1f9200(int);
extern void func_0c1f91d0(int);
extern void func_0c1f92c0(void);
extern int func_0c1f91a0(int, int *);
extern void func_0c200994(int, int *, int *);
extern void func_0c1f99a8(int, int *, int *);
extern void func_0c1f9ae0(int, int *, int *, int, int *, int *);

void func_0c1f92e0(void)
{
    int *end;
    register int *cursor;
    int clear = 0;
    dat_0c345434 = clear;
    dat_0c345438 = clear;
    end = dat_0c345424 + 4;
    cursor = dat_0c345424;
    do { *cursor++ = clear; } while (cursor < end);
}
void func_0c1f92fe(void)
{
    int *values = func_0c1f9190();
    int i;
    dat_0c343d60 = 0;
    for (i = 0; i < 4; i++) {
        int *timers = dat_0c345424;
        if (timers[i] > 6) {
            dat_0c343d60 |= 1 << i;
            dat_0c345424[i]--;
        } else if (timers[i] > 0) {
            timers[i]--;
            values[i] = 0;
        } else if (values[i] != 0) {
            timers[i] = 12;
        }
    }
}

void func_0c1f9370(void) { dat_0c345420 = 0; }
void func_0c1f9378(void) { dat_0c345420 = 1; }
void func_0c1f9380(void){int first[4];int second[4];int *status;int i;int next;int clear;if(dat_0c345420==0 && func_0c1f9290()!=1){clear=0;for(i=0;i<4;i++){first[i] = clear;second[i] = clear;}status=&dat_0c345434;        if (dat_0c345440 == 0) {
            func_0c200994(0, &dat_0c345434, first);
        } else if (dat_0c345440 == 1) {
            func_0c1f99a8(1, &dat_0c345434, first);
        } else if (dat_0c345440 == 2) {
            func_0c1f9ae0(2, &dat_0c345434, first, 1, &dat_0c345438, second);
            *status &= 16;
            dat_0c345438 &= 16;
            *status |= dat_0c345438 << 1;
            first[1] = second[0];
            first[2] = 0; first[3] = 0;
        } else {
            func_0c1f99a8(dat_0c345444, &dat_0c345434, first);
        }
        if (dat_0c343d48 == 0) {
            dat_0c353f3c += func_0c1f91a0(*status, first);
            func_0c1f92fe();
        }
        func_0c1f92c0();
    }
}

void func_0c1f949c(void)
{
    unsigned int *ticks;
    int result;
    if (dat_0c343d48 == 0) {
        if (dat_0c353f3c != 0) {
            result = func_0c1f7570();
            if (result == 1) {
                unsigned int mask = _builtin_get_imask();
                _builtin_set_imask(15);
                func_0c1f9200(result);
                dat_0c353f3c = 0;
                _builtin_set_imask(mask);
            }
        }
        ticks = &dat_0c34543c;
        (*ticks)++;
        if ((*ticks & 15) == 0) {
            result = func_0c1f7570();
            if (result == 1) {
                func_0c1f91d0(result);
                return;
            }
            *ticks = 15;
        }
    }
}
