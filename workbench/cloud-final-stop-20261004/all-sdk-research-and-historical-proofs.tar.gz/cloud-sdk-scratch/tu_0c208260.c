/* Unregistered SDK transfer wrapper [0c208260,0c2082d4). */
struct SdkTransferJob { unsigned int index; unsigned int size; };
struct SdkTransferPacket { unsigned int *table; const void *source; struct SdkTransferJob *job; };
extern void func_0c206a40(void *, const void *, unsigned int);
extern void _builtin_prefetch(void *);
int func_0c208260(struct SdkTransferPacket *packet){int index;
unsigned int address;
unsigned int size;index=packet->job->index;address=((packet->table[index] & 0x03ffffff) | 0xe0000000);*(volatile unsigned int *)0xff000038=*(volatile unsigned int *)0xff00003c=packet->table[index]>>24;size=packet->job->size;func_0c206a40((void *)address,packet->source,size);_builtin_prefetch((void *)address);if(size==64){address+=32;_builtin_prefetch((void *)address);}packet->table[index]+=(size>>2)<<2;return 0;}
