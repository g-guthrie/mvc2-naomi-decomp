/* WITHDRAWN: already owned by lib_shinobi_sy_g2_dma_reset_, zero new credit. */
/* UNREGISTERED SDK reset [0c21b7f0,0c21b8bc), not compiled or credited. */
#include "objects.h"
extern struct SdkCompletionControl *dat_0c269a7c;
#define SDK_PACKET(index) ((struct SdkCompletionPacket *)((char *)dat_0c269a7c + 4) + (index))
int func_0c21b7f0(struct SdkCompletionPacket *packet)
{
    SDK_PACKET(packet->index)->index = packet->index;
    SDK_PACKET(packet->index)->pad2[4] = 0; /* TODO: real 32-bit field at 0x28 */
    SDK_PACKET(packet->index)->state = 0;
    SDK_PACKET(packet->index)->pending = 0;
    /* Remaining retail word stores at offsets 4,8,c,10,14,18,1c,20
     * need typed packet fields before any registration. Offset18 gets3. */
    dat_0c269a7c->entries[packet->index].completion = 0;
    return 0;
}
