/* Unregistered SDK retry-request pair, complete extent0c20b8d0..0c20b9ac. */
struct SdkRetryState { char pad[0x30]; int serial; int retries; char tail[0x110]; };
struct SdkRequestContext { char pad[8]; int parameter; char tail[0x74]; };
extern int dat_0c3a7ec4;
extern int dat_0c2387d0;
extern struct SdkRetryState dat_0c3aa300[];
extern struct SdkRequestContext dat_0c3a7ee8[];
extern int func_0c21b99c(int, int);
extern void func_0c20bf7a(int, int, int, int);
int func_0c20b8d0(int count)
{
    dat_0c3a7ec4 = count;
    return count;
}
int func_0c20b8d8(int index, int request)
{
    int result;
    struct SdkRequestContext *context;
    int count = dat_0c3a7ec4;
    struct SdkRetryState *state = &dat_0c3aa300[index];
    int busy = -208;
    do {
        result = func_0c21b99c(index, request);
        if (result == 0) break;
        if (dat_0c2387d0 && result == busy) goto failure;
        state->retries++;
    } while (count-- || dat_0c3a7ec4 == -1);
    state = &dat_0c3aa300[index];
    context = &dat_0c3a7ee8[index];
    func_0c20bf7a(index, context->parameter, state->serial++, state->retries);
    switch(result) {
case -255:
failure: return -255;
case 0: return 0;
default: return -65536;
    }
}
