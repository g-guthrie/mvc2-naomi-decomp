/* UNREGISTERED SDK powers-of-five normalization [0c204718,0c2047b0).
 * Observed caller204340 passes index1..26, selecting nonzero table entry.
 * Retail shift return is ignored. No direct compiler runtime calls. */
extern void func_0c203d54(int, unsigned char *);
extern void *func_0c1fba00(void *, int, unsigned int);
extern int func_0c203d08(unsigned char *, int, short);
extern void *func_0c1fb940(void *, const void *, unsigned int);
void func_0c204718(int index, short *exponent, unsigned char *output)
{
    unsigned char temporary[8];
    unsigned char *cursor;
    int skipped = 0;
    int shift = 0;
    unsigned int mask = 128;
    int remaining;
    *exponent = index + 63;
    func_0c203d54(index, temporary);
    func_0c1fba00(output, 0, 8);
    cursor = temporary;
    while (*cursor == 0) {
        skipped++;
        cursor++;
        *exponent -= 8;
    }
    while ((*cursor & (unsigned char)mask) == 0) {
        mask = (unsigned char)mask;
        shift++;
        mask >>= 1;
    }
    remaining = 8 - skipped;
    func_0c203d08(cursor, remaining, shift);
    *exponent -= shift;
    func_0c1fb940(output, cursor, remaining);
}
