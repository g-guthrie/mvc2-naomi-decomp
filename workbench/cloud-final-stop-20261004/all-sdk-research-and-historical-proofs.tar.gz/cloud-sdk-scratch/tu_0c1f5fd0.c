/* Unregistered SDK command submission, complete extent [0c1f5fd0,0c1f6080). */
extern unsigned int dat_0c344d64;
extern unsigned int dat_0c344d68;
extern unsigned int *dat_0c344d6c;
extern unsigned int *dat_0c344d70;
extern unsigned int *dat_0c344d74;
unsigned int *func_0c1f5fd0(unsigned int flags)
{
    volatile unsigned int *status = (volatile unsigned int *)0xa05f6c18;
    unsigned int **start;
    unsigned int **cursor;
    unsigned int *word;
    while (*status) {}
    *dat_0c344d6c = (unsigned int)-1;
    start = &dat_0c344d70;
    cursor = &dat_0c344d74;
    word = *start;
    *cursor = word + 1;
    *word = 0x80000000;
    *(*cursor)++ = dat_0c344d64;
    *(*cursor)++ = flags | 0x2000;
    word = *start;
    *word |= ((((int)*cursor-(int)word) < 0 ? ((int)*cursor-(int)word) + 3 : ((int)*cursor-(int)word)) >> 2) - 3;
    word = *start;
    word[2] |= (unsigned char)*word << 24;
    while (*status) {}
    *(volatile unsigned int *)0xa05f6c04 = dat_0c344d68;
    *(volatile unsigned int *)0xa05f6c14 = 1;
    *status = 1;
    while (*status) {}
    return dat_0c344d6c;
}
