/* Unregistered SDK pool-free loop. */
#pragma section L0
void func_0c1f7740(int count,int *dest,int *source){do{*dest++=*source++;}while(count--);}
