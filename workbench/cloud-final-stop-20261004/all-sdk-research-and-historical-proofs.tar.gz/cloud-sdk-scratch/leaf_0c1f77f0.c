/* Unregistered SDK pool-free loop. */
#pragma section L0
void func_0c1f77f0(int unused,char *source,char *dest,int count){do{*dest++=*source++;}while(count--);}
