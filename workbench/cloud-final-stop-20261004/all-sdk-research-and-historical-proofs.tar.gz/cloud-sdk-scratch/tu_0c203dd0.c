/* UNREGISTERED SDK byte subtraction [0c203dd0,0c203e48).
 * Retail performs subtraction in place; return is -1 for disallowed
 * underflow, 0 for zero result, and 1 otherwise. */
int func_0c203dd0(int allow_underflow, unsigned char *left,
                unsigned char *right, int count)
{
    int offset = count - 1;
    unsigned char *source = right + offset;
    unsigned char *cursor = left + offset;
    unsigned char *output = cursor + 1;
    int borrow = 0;
    int zero = 1;
    while (cursor >= left) {
        int difference = (int)*cursor - (int)*source - borrow;
        if (difference < 0) {
            difference += 256;
            borrow = 1;
        } else {
            borrow = 0;
        }
        if (difference != 0)
            zero = 0;
        *--output = difference;
        cursor--;
        source--;
    }
    if (borrow == 1 && allow_underflow == 0)
        return -1;
    if (zero == 1)
        return 0;
    return 1;
}
