/* Compiler API probe only, not a decompilation candidate, zero credit. */
void func_0c210720(void *address)
{
    _builtin_ocbp(address);
}
