/* SDK pool-free float identity. Exact extent 0c1ebef0..0c1ebef4. */
#pragma section L0
float func_0c1ebef0(float value) { return value; }
