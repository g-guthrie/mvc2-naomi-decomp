/* UNREGISTERED SDK rounding [0c204494,0c204580).
 * Native calls reviewed at2039e2,2043e8,20442c pass bit64.
 * Ordinary source contract: bit > 0; buffer includes guard/round/sticky bits.
 * Guard+round+sticky/retained-LSB decide ties-to-even; carry overflow returns1.
 */
int func_0c204494(unsigned char *bytes, int bit)
{
    unsigned char *guard = bytes + bit / 8;
    int mask = (unsigned char)(128 >> (bit % 8));
    int round = mask >> 1;
    unsigned char sticky = mask >> 2;
    unsigned char *cursor = bytes + (bit - 1) / 8;
    unsigned int retained = 128 >> ((bit - 1) % 8);
    int increment = 0;
    if (*guard & mask) {
        if ((*guard & round) || (*guard & sticky))
            increment = 1;
        else if (*cursor & (unsigned char)retained)
            increment = 1;
    }
    if (increment == 1) {
        while ((*cursor & (unsigned char)retained) && cursor >= bytes) {
            *cursor &= ~retained;
            retained <<= 1;
            if ((unsigned char)retained == 0) {
                retained = 1;
                cursor--;
            }
        }
        if (cursor >= bytes)
            *cursor |= retained;
        else
            return 1;
    }
    return 0;
}
