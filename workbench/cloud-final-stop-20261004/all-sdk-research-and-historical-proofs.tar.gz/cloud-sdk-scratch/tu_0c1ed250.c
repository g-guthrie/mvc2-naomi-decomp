/* Unregistered SDK draft, complete extent 0c1ed250..0c1ed280. */
struct SdkGbrState { signed char dirty; signed char mode; };
#pragma gbr_base(dat_0c3a4740)
extern struct SdkGbrState dat_0c3a4740;
extern char dat_0c3a47c0[];
void func_0c1ed250(int index, short *source, int count)
{
    index *= 4;
    if (dat_0c3a4740.mode != 3) {
        do {
            *(short *)(index + (int)dat_0c3a47c0) = *source++;
            index += 4;
        } while (--count);
        dat_0c3a4740.dirty = 1;
        return;
    } else {
        do {
            *(int *)(index + (int)dat_0c3a47c0) = *(int *)source;
            source += 2;
            index += 4;
        } while (--count);
        dat_0c3a4740.dirty = 1;
        return;
    }
}
