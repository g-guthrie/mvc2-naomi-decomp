/* SDK table scratch, complete extent [0c2255a0,0c2255c4). */
struct SdkPair { int first; int second; };
struct SdkTable { int unused; int value; struct SdkPair entries[1]; };
extern struct SdkTable dat_0c3b22e0;
int func_0c2255a0(int index) { struct SdkTable *table=&dat_0c3b22e0; table->entries[index].first=table->value; table->entries[index].second=0; return 0; }
