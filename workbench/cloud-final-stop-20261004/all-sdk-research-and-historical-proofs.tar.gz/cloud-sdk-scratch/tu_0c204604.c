/* UNREGISTERED SDK byte-array addition [0c204604,0c20464c).
 * 66 code bytes and six pool bytes. Whole boundary audit has no crossings.
 * C arithmetic invokes the compiler division runtime; no direct runtime call.
 * INEXACT: register allocation and two-byte pool alignment differ. */
void func_0c204604(unsigned char *destination, unsigned char *source, int count)
{
    int offset = count - 1;
    unsigned char *last_source = source + offset;
    unsigned char *cursor = destination + offset;
    int carry = 0;
    while (cursor >= destination) {
        int total = *cursor + *last_source + carry;
        *cursor = total;
        carry = total / 256;
        cursor--;
        last_source--;
    }
}
