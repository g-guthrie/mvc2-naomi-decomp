/* UNREGISTERED SDK one-bit right shift [0c2047b0,0c2047fa).
 * Native has no pool; adjacent zero alignment at7fa excluded.
 * Carries propagate forward, final low bit returned. No volatile forcing. */
#pragma section RightShift
unsigned int func_0c2047b0(unsigned char *bytes, int count)
{
    unsigned char *input = bytes;
    unsigned char *output = bytes;
    unsigned int carry = 0;
    int index;
    for (index = 0; index < count; index++) {
        unsigned int next = *input & 1;
        *input = *input >> 1;
        if (carry)
            *output |= 128;
        carry = next;
        output++;
        input++;
    }
    return carry;
}
