/* PARKED INEXACT: dynamic caller bit domain is not proven.
 * Negative shift count/pointer bounds require review before promotion.
 * UNREGISTERED SDK sticky-bit update [0c204580,0c204604).
 * Native ROM selects the indexed bit and folds lower bits into it.
 * Division/remainder use ordinary C and the approved compiler options. */
void func_0c204580(unsigned char *bytes, int count, int bit)
{
    unsigned char *selected = bytes + bit / 8;
    unsigned char *cursor = selected;
    int mask;
    if (bit >= 0)
        bit &= 7;
    else
        bit = (int)(~((~(unsigned int)bit + 1u) & 7u) + 1u);
    mask = 128 >> bit;
    if ((*cursor & (unsigned char)mask) == 0) {
        int lower = 0;
        unsigned int scan;
        scan = mask;
        while ((unsigned char)scan != 0) {
            lower |= scan;
            scan = (unsigned char)scan;
            scan >>= 1;
        }
        if (*cursor & (unsigned char)lower) {
            *cursor |= mask;
        } else {
            bytes += count;
            while (++cursor < bytes) {
                if (*cursor != 0) {
                    *selected |= mask;
                    break;
                }
            }
        }
    }
}
