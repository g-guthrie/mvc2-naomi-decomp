/* Unregistered SDK pool-free loop. */
#pragma section L0
void func_0c1f7ad0(int count,char *dest,char value){do{*dest++=value;}while(count--);}
