/* SDK pool-free float negation. Extent 0c1ec350..0c1ec358. */
#pragma section L0
float func_0c1ec350(float value) { return -value; }
