/* SDK scratch, zero credit. */
struct SdkStatus {char reserved[0xfc0]; int flag;};
extern struct SdkStatus *dat_0c3b4a48;
extern unsigned char *dat_0c220040;
int func_0c21cae8(void){
unsigned char *q = (unsigned char *)dat_0c220040;
dat_0c3b4a48->flag = 1;
*q = 0;
return 0;
}
