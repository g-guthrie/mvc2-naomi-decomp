/* UNREGISTERED four-function SDK group [0c210b60,0c210eb4).
 * Complete native semantics; no synthetic padding, volatile forcing or asm.
 * Private record types must move to objects.h before any registration.
 */
struct SdkNativeSourceRecord {
    unsigned char first[4]; unsigned char unused0[4];
    unsigned char second[4]; unsigned char unused1[4];
    unsigned int value0, value1; unsigned char tail[20];
};
struct SdkNativeSourceTable {
    unsigned char header[40]; struct SdkNativeSourceRecord records[24];
};
struct SdkNativeDestinationRecord {
    unsigned char first[4], second[4];
    unsigned int value0, value1; unsigned char tail[8];
};
extern struct SdkNativeSourceTable *dat_0c3b4a48;
extern struct SdkNativeDestinationRecord dat_0c3b199c[24];
extern int dat_0c3b190c, dat_0c3b1910, dat_0c3b1914, dat_0c3b1918;
extern int dat_0c23885c, dat_0c238860, dat_0c238864, dat_0c238868;
extern int dat_0c3b1c1c, dat_0c3b1e6c, dat_0c3b1e70, dat_0c3b1e74;
extern int dat_0c3b1e78, dat_0c3b1e80, dat_0c3b1e7c, dat_0c3b1e94;
extern int dat_0c3b1e98, dat_0c3b1e9c, dat_0c3b1c24, dat_0c3b1ea0;
extern unsigned char dat_0c3b1bdc[64], dat_0c3b1c28[576], dat_0c3b191c[128];
extern unsigned int dat_0c220040;
extern int dat_0c3b1e68;
extern void func_0c210880(void), func_0c2108e0(void);
extern void func_0c210ac0(void), func_0c210b00(void);
extern int func_0c210190(int, void (*)(void), int, int);
extern int func_0c21bf60(int, int, int, int);
extern int func_0c21c108(int, int, int, int);
extern void *func_0c1fba00(void *, int, unsigned int);
void func_0c210b60(void)
{
    struct SdkNativeDestinationRecord *destination = dat_0c3b199c;
    struct SdkNativeSourceRecord *source = dat_0c3b4a48->records;
    int index;
    for (index = 0; index < 24; index++) {
        destination->first[0] = source->first[0];
        destination->first[1] = source->first[1];
        destination->first[2] = source->first[2];
        destination->first[3] = source->first[3];
        destination->value0 = source->value0;
        destination->second[0] = source->second[0];
        destination->second[1] = source->second[1];
        destination->second[2] = source->second[2];
        destination->second[3] = source->second[3];
        destination->value1 = source->value1;
        destination++;
        source++;
    }
}
void func_0c210c10(void)
{
    dat_0c3b190c = func_0c210190(0x900, func_0c210880, dat_0c23885c, 0);
    dat_0c3b1910 = func_0c210190(0xa00, func_0c2108e0, dat_0c238860, 0);
    dat_0c3b1914 = func_0c210190(0xa00, func_0c210ac0, dat_0c238864, 0);
    dat_0c3b1918 = func_0c210190(0xa20, func_0c210b00, dat_0c238868, 0);
    dat_0c3b1c1c = 0;
    dat_0c3b1e6c = 0;
    dat_0c3b1e70 = 0;
    dat_0c3b1e74 = 0;
    dat_0c3b1e78 = 0;
    dat_0c3b1e80 = 0;
    dat_0c3b1e7c = -1;
    dat_0c3b1e94 = 0;
    dat_0c3b1e98 = 0;
    dat_0c3b1e9c = 0;
    dat_0c3b1c24 = 0;
    dat_0c3b1ea0 = 0;
    func_0c1fba00(dat_0c3b1bdc, 0, 64);
    func_0c1fba00(dat_0c3b199c, 0, 576);
    func_0c1fba00(dat_0c3b1c28, 0, 576);
    func_0c1fba00(dat_0c3b191c, 0, 128);
}
int func_0c210da0(int first, int second)
{
    unsigned int mask = _builtin_get_imask();
    int result;
    _builtin_set_imask(15);
    dat_0c220040 |= 0xa0000000u;
    func_0c210c10();
    result = func_0c21bf60(second, 0xc000, first, 0xc000);
    func_0c210b60();
    dat_0c3b1e68 = 1;
    _builtin_set_imask(mask);
    return result;
}
int func_0c210e28(int first, int second, int third, int fourth)
{
    unsigned int mask = _builtin_get_imask();
    int result;
    _builtin_set_imask(15);
    dat_0c220040 |= 0xa0000000u;
    func_0c210c10();
    result = func_0c21c108(first, second, third, fourth);
    func_0c210b60();
    dat_0c3b1e68 = 1;
    _builtin_set_imask(mask);
    return result;
}
