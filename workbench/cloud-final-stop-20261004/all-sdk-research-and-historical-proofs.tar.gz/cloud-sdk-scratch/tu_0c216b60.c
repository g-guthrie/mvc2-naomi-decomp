/* SDK scratch zero credit. */
int func_0c216b60(unsigned int value, unsigned int *a, unsigned int *b, unsigned int *c, unsigned int *d, unsigned int *e){
*a = value & 3;
*b = (value >> 4) & 3;
*c = (value >> 8) & 3;
*d = (value >> 12) & 3;
*e = (value >> 16) & 3;
return 0;}
