/* Unregistered SDK matrix stack pop, extent 0c1ee360..0c1ee3a4. */
struct MatrixStack { short count; short minimum; float *base; float *top; };
extern struct MatrixStack dat_0c33f630;
int func_0c1ee360(int amount)
{
    int remaining, valid;
    float *matrix;
    if (amount <= 0) amount = 1;
    remaining = dat_0c33f630.count;
    valid = remaining >= amount;
    remaining -= amount;
    if (!valid) remaining = 0;
    dat_0c33f630.count = remaining;
    matrix = (float *)((char *)dat_0c33f630.base + (((unsigned int)remaining << 8) >> 2));
    if (remaining < dat_0c33f630.minimum) dat_0c33f630.top = matrix;
    _builtin_ld_ext(matrix);
    return valid;
}
