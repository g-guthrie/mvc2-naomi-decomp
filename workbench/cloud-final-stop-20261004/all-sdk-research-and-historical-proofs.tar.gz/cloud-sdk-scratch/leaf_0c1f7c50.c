/* Unregistered SDK pool-free loop. */
#pragma section L0
void func_0c1f7c50(int count,int unused,char *source,char *dest){do{*dest++=*source++;}while(count--);}
