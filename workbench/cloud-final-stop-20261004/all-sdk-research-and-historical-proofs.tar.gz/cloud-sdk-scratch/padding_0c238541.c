/* Actual three zero alignment bytes after the SDK version constant. */
#pragma section tail
const unsigned char dat_0c238541[3] = { 0, 0, 0 };
