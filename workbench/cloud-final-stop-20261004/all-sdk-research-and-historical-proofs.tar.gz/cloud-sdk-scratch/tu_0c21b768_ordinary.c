/* Unregistered SDK queue completion, whole extent [0c21b768,0c21b7f0). */
struct SdkCompletionEntry { char pad[0x14]; int completion; char tail[8]; };
struct SdkCompletionControl { struct SdkCompletionEntry *entries; char pad[0xe8]; int counters[1]; };
struct SdkCompletionPacket {
    int index; char pad[0x18]; void (*callback)(void *); void *context;
    char pad2[8]; int state; int pending;
};
extern struct SdkCompletionControl *dat_0c269a7c;
extern int *dat_0c269a74;
void func_0c21b768(struct SdkCompletionPacket *packet)
{
 unsigned int mask=_builtin_get_imask();
struct SdkCompletionEntry *entries;
int clear;
register int flag;
 _builtin_set_imask(15);
clear=0;
entries=dat_0c269a7c->entries;
entries[packet->index].completion=clear;
flag=1;
packet->state=clear;
packet->pending=flag;
dat_0c269a7c->counters[packet->index]++;
*dat_0c269a74=flag << (packet->index+15);
if(packet->callback)packet->callback(packet->context);
_builtin_set_imask(mask);
}
