/* Compiler API probe only; not a decompilation candidate, zero credit. */
int func_0c210720(void)
{
    return _builtin_get_cr();
}
