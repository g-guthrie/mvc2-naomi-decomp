/* Unregistered SDK tick service [0c1f949c,0c1f953c). */
extern int dat_0c343d48;
extern int dat_0c353f3c;
extern unsigned int dat_0c34543c;
extern int func_0c1f7570(void);
extern void func_0c1f9200(int);
extern void func_0c1f91d0(int);
void func_0c1f949c(void)
{
    unsigned int *ticks;
    int result;
    if (dat_0c343d48 == 0) {
        if (dat_0c353f3c != 0) {
            result = func_0c1f7570();
            if (result == 1) {
                unsigned int mask = _builtin_get_imask();
                _builtin_set_imask(15);
                func_0c1f9200(result);
                dat_0c353f3c = 0;
                _builtin_set_imask(mask);
            }
        }
        ticks = &dat_0c34543c;
        (*ticks)++;
        if ((*ticks & 15) == 0) {
            result = func_0c1f7570();
            if (result == 1) {
                func_0c1f91d0(result);
                return;
            }
            *ticks = 15;
        }
    }
}
