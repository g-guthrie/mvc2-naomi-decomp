/* Unregistered SDK converter extent [0c2047fc,0c20481a). */
void func_0c2047fc(unsigned char *destination, const unsigned short *source)
{
int shift = 8;
unsigned char *cursor = destination;
unsigned char *end = destination + 2;
do{*cursor = *source >> shift; cursor++; shift-=8;}while(cursor<end);
}
