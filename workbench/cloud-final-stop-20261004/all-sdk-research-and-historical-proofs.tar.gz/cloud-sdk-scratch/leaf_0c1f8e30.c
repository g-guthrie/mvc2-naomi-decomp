/* Unregistered SDK pool-free loop. */
#pragma section L0
void func_0c1f8e30(int count,int *source,int *dest){do{*dest++=*source++;}while(count--);}
