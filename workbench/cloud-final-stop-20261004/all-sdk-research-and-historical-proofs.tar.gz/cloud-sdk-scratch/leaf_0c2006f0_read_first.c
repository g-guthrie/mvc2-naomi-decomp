/* UNREGISTERED alias-order review: byte read precedes pointer-field update.
 * SDK byte consumer [0c2006f0,0c200710).
 * Native fields: input count0, output count4, output pointer8,input pointer12.
 * Private research type; move to objects.h before any registration. */
struct SdkByteConsumer {
    int input_count;
    int output_count;
    unsigned char *output;
    const unsigned char *input;
};
#pragma section Consumer
unsigned int func_0c2006f0(struct SdkByteConsumer *state)
{
    unsigned int value = *state->input;
    state->input++;
    state->input_count--;
    state->output++;
    state->output_count--;
    return value;
}
