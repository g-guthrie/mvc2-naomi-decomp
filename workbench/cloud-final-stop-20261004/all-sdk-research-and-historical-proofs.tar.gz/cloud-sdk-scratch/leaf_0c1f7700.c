/* Unregistered SDK byte fill. */
#pragma section L0
void func_0c1f7700(int count,char *dest,char value){int old;do{*dest=value;dest++;}while(count--);}
