/* UNREGISTERED SDK guarded increment [0c1f6810,0c1f682c).
 * 22 native executable bytes, six NOP padding bytes. No literal pool.
 * The apparent leaf6820 is an internal branch target, not an independent TU. */
int func_0c1f6810(int *counter)
{
    if (*counter == -1)
        return 0;
    return ++*counter;
}
