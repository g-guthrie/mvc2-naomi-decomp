/* WITHDRAWN OWNED DUPLICATE idx_byte_s4; ZERO new credit.
 * SDK byte-field setter [0c1f3f30,0c1f3f3c).
 * Native index sign extension, four-byte stride, field offset49.
 * Adjacent four NOP bytes excluded; no literal pool. */
#pragma section Setter
void func_0c1f3f30(unsigned char *record, short index, unsigned char value)
{
    record[index * 4 + 49] = value;
}
