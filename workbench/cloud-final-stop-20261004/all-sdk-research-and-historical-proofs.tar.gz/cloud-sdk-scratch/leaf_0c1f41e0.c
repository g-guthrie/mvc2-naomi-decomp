/* SDK empty function, full pool-free extent 0c1f41e0..0c1f41e4. */
#pragma section L0
void func_0c1f41e0(void) { }
