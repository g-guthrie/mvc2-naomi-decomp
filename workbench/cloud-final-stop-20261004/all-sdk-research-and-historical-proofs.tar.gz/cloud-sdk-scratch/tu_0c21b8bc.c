/* Unregistered SDK scratch. */
extern unsigned int dat_0c269a78;
int func_0c21b8bc(unsigned int a,unsigned int b){unsigned int packed;a = (a & 0x07f00000) >> 20; b = (b & 0x07f00000) >> 20; packed = (a << 8) | b | 0x46590000;*(unsigned int *)0xa05f78bc = packed;dat_0c269a78 = packed;return 0;}
