/* Complete SDK marker consumer [0c20075c,0c200790); native audit only, zero credit. */
#include "objects.h"
#pragma section ConsumerMarkerSkip
unsigned int func_0c20075c(struct SdkByteConsumer *state)
{
    unsigned int value = *state->input;
    state->input++;
    state->input_count--;
    state->output++;
    state->output_count--;
    if (value != 2) {
        state->input++;
        state->input_count--;
    }
    return value;
}
