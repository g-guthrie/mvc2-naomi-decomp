/* SDK allocation wrapper scratch, extent 0c222180..0c2221e8. */
extern int func_0c227140(int,unsigned int,int *);
extern int func_0c227180(int);
int func_0c222180(unsigned int size,int *first,int *second){unsigned int aligned;int original;int result;aligned=((size & 31)==0)?size:(size+32)&~31;*first=0;result=func_0c227140(2,(aligned)<<1,first);if(result==0){original=*first;*first=func_0c227180(original);*second=func_0c227180(original+4);}return result;}
